import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class JobPortal {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/jomboo";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Koushik5@";

    private Map<String, Job> jobs;
    private Map<String, User> users;
    private Scanner scanner;

    public JobPortal() {
        jobs = new HashMap<>();
        users = new HashMap<>();
        scanner = new Scanner(System.in);
        initializeDatabase();
    }

    private void initializeDatabase() {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement()) {
            String createTableQuery = "CREATE TABLE IF NOT EXISTS jobs (title VARCHAR(255), description VARCHAR(1000))";
            stmt.executeUpdate(createTableQuery);

            createTableQuery = "CREATE TABLE IF NOT EXISTS users (username VARCHAR(100) PRIMARY KEY)";
            stmt.executeUpdate(createTableQuery);

            createTableQuery = "CREATE TABLE IF NOT EXISTS applications (user_id INT, job_title VARCHAR(255))";
            stmt.executeUpdate(createTableQuery);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addJob(Job job) {
        jobs.put(job.getTitle(), job);
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String insertQuery = "INSERT INTO jobs (title, description) VALUES (?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(insertQuery);
            pstmt.setString(1, job.getTitle());
            pstmt.setString(2, job.getDescription());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void registerUser(User user) {
        users.put(user.getUsername(), user);
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String insertQuery = "INSERT INTO users (username) VALUES (?)";
            PreparedStatement pstmt = conn.prepareStatement(insertQuery);
            pstmt.setString(1, user.getUsername());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void displayJobListings() {
        System.out.println("Available Job Listings:");
        for (Job job : jobs.values()) {
            System.out.println(job.getTitle() + ": " + job.getDescription());
        }
    }

    public List<String> searchJobs(String keyword) {
        List<String> searchResults = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT title, description FROM jobs WHERE title LIKE ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, "%" + keyword + "%");

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                String title = rs.getString("title");
                String description = rs.getString("description");
                searchResults.add(title + ": " + description);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return searchResults;
    }

    public void applyForJob(String username, String jobTitle) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String applicationQuery = "INSERT INTO applications (user_id, job_title) VALUES ((SELECT id FROM users WHERE username = ?), ?)";
            PreparedStatement applicationPstmt = conn.prepareStatement(applicationQuery);
            applicationPstmt.setString(1, username);
            applicationPstmt.setString(2, jobTitle);
            applicationPstmt.executeUpdate();

            System.out.println("Application submitted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewUserProfile(String username) {
        User user = users.get(username);
        if (user == null) {
            System.out.println("User not found.");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT job_title FROM applications WHERE user_id = (SELECT id FROM users WHERE username = ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, username);

            ResultSet rs = pstmt.executeQuery();
            List<Job> appliedJobs = new ArrayList<>();
            while (rs.next()) {
                String jobTitle = rs.getString("job_title");
                Job job = jobs.get(jobTitle);
                if (job != null) {
                    appliedJobs.add(job);
                }
            }

            System.out.println("User Profile:");
            System.out.println("Username: " + user.getUsername());
            System.out.println("Email: " + user.getEmail());

            if (!appliedJobs.isEmpty()) {
                System.out.println("Applied Jobs:");
                for (Job job : appliedJobs) {
                    System.out.println(job.getTitle() + ": " + job.getDescription());
                }
            } else {
                System.out.println("No job applications found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void run() {
        System.out.println("Welcome to the Job Portal!");
        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Display Job Listings");
            System.out.println("2. Search for Jobs");
            System.out.println("3. Register as a User");
            System.out.println("4. Apply for a Job");
            System.out.println("5. View User Profile");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    displayJobListings();
                    break;
                case 2:
                    System.out.print("Enter the keyword to search for jobs: ");
                    String keyword = scanner.nextLine();
                    List<String> searchResults = searchJobs(keyword);
                    System.out.println("Search Results:");
                    for (String result : searchResults) {
                        System.out.println(result);
                    }
                    break;
                case 3:
                    System.out.print("Enter your username: ");
                    String username = scanner.nextLine();
                    System.out.print("Enter your email: ");
                    String email = scanner.nextLine();
                    User newUser = new User(username, email);
                    registerUser(newUser);
                    break;
                case 4:
                    System.out.print("Enter your username: ");
                    String applicantUsername = scanner.nextLine();
                    System.out.print("Enter the job title you want to apply for: ");
                    String jobTitle = scanner.nextLine();
                    applyForJob(applicantUsername, jobTitle);
                    break;
                case 5:
                    System.out.print("Enter your username: ");
                    String userProfileUsername = scanner.nextLine();
                    viewUserProfile(userProfileUsername);
                    break;
                case 6:
                    System.out.println("Thank you for using the Job Portal. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    public static void main(String[] args) {
        JobPortal jobPortal = new JobPortal();

        // Add sample job listings
        jobPortal.addJob(new Job("Software Engineer", "Develop and maintain software applications."));
        jobPortal.addJob(new Job("Data Analyst", "Analyze and interpret data to provide insights."));

        jobPortal.run();
    }
}
