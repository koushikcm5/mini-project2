import java.util.ArrayList;
import java.util.List;

public class User {
    private String username;
    private String email;
    private List<Job> appliedJobs;

    public User(String username, String email) {
        this.username = username;
        this.email = email;
        this.appliedJobs = new ArrayList<>();
    }

    public User(String username, String email, List<Job> appliedJobs) {
        this.username = username;
        this.email = email;
        this.appliedJobs = appliedJobs;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public List<Job> getAppliedJobs() {
        return appliedJobs;
    }

    public void applyForJob(Job job) {
        appliedJobs.add(job);
    }

    public void displayAppliedJobs() {
        System.out.println("Applied Jobs:");
        for (Job job : appliedJobs) {
            System.out.println(job.getTitle() + ": " + job.getDescription());
        }
    }
}
